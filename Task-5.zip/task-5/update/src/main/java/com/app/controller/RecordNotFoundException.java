package com.app.controller;

public class RecordNotFoundException extends RuntimeException {
    public RecordNotFoundException(String message) {
    	super(message);
    }
}
